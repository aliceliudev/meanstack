const mongoose = require('mongoose');
const Food = mongoose.model('Food');

const getFoods = function (req, res){
    res
    .status(200)
    .json({"status": "success"});
}
const getSingleFood = function (req, res){
    res
    .status(200)
    .json({"status": "success"});
}
const updateFood = function (req, res){
    res
    .status(200)
    .json({"status": "success"});
}
const createFood = function (req, res){
    res
    .status(200)
    .json({"status": "success"});
}
const deleteFood = function (req, res){
    res
    .status(200)
    .json({"status": "success"});
}

module.exports = {
    getFoods, 
    createFood,
    getSingleFood,
    updateFood,
    deleteFood
};